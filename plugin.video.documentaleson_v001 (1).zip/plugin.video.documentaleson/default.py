# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Plugin Parser de la web DocumentalesON.com  by Bad-Max
# Version 0.0.1 (26-12-2021)
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Gracias a la librería plugintools de Jesús (www.mimediacenter.info), PlatformCode y Core del Grupo Balandro (https://linktr.ee/balandro)

import os, sys, urllib, re, shutil, zipfile, base64
import xbmc, xbmcgui, xbmcaddon, xbmcplugin, requests
import locale, time, random, plugintools
import resolvers

if sys.version_info[0] < 3:
    import urllib2
else:
    import urllib.error as urllib2

from core import httptools
from core.item import Item
from platformcode.config import WebErrorException


addonName           = xbmcaddon.Addon().getAddonInfo("name")
addonVersion        = xbmcaddon.Addon().getAddonInfo("version")
addonId             = xbmcaddon.Addon().getAddonInfo("id")
addonPath           = xbmcaddon.Addon().getAddonInfo("path")

version="(v0.0.1)"

addonPath           = xbmcaddon.Addon().getAddonInfo("path")
mi_data = xbmc.translatePath(os.path.join('special://home/userdata/addon_data/plugin.video.documentaleson/'))
mi_addon = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.documentaleson'))

fondo = xbmc.translatePath(os.path.join(mi_addon,'fanart.jpg'))
logo1 = xbmc.translatePath(os.path.join(mi_addon,'icon.png'))

mislogos = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.documentaleson/jpg/'))
logobusca = xbmc.translatePath(os.path.join(mislogos , 'buscar.jpg'))
logo_volver = xbmc.translatePath(os.path.join(mislogos , 'volver.png'))
logo_siguiente = xbmc.translatePath(os.path.join(mislogos , 'siguiente.png'))
logo_finpag = xbmc.translatePath(os.path.join(mislogos , 'final.png'))
logo_transparente = xbmc.translatePath(os.path.join(mislogos , 'transparente.png'))
logo_salida = xbmc.translatePath(os.path.join(mislogos , 'salida.png'))
no_disponible = xbmc.translatePath(os.path.join(mislogos , 'no_disponible.jpg'))

setting = xbmcaddon.Addon().getSetting
marcar_visto = False
pregunta_marcar = False
if setting('marcar_visto') == "true":
    marcar_visto = True
if setting('pregunta_marcar') == "true":
    pregunta_marcar = True    

if setting('youtube_usar') == "0":  ##Tiene escogido el plugin Youtube
    usa_duffyou = False
else:  ##Ha escogido usar Duff You
    usa_duffyou = True

youtube = "plugin://plugin.video.youtube/play/?video_id=MI-ID-VIDEO"
duffyou = "eydhY3Rpb24nOiAncGxheScsICdhdXRob3JfaWQnOiAnJywgJ2F1dGhvcl9uYW1lJzogJycsICdkdXJhdGlvbic6IDAsICdmYW5hcnQnOiAnJywgJ2ljb24nOiAnJywgJ2lkJzogJ01JLUlELVZJREVPJywgJ2lzUGxheWFibGUnOiBUcnVlLCAnbGFiZWwnOiAnJywgJ3BhZ2UnOiAxLCAncGxvdCc6ICcnLCAndGh1bWInOiAnJywgJ3RpcG8nOiAndmlkZW8nLCAndXJsJzogJyd9"


web = "https://www.documentaleson.com/"

if not os.path.exists(mi_data):
	os.makedirs(mi_data)  # Si no existe el directorio, lo creo

vistos = xbmc.translatePath(os.path.join('special://home/userdata/addon_data/plugin.video.documentaleson/vistos.db'))
if not os.path.exists(vistos):
    if sys.version_info[0] < 3:
        crear=open(vistos, "w+")
    else:
        crear=open(vistos, "w+", encoding='utf-8')
    crear.close()

cabecera = "[COLOR yellow][B]              DocumentalesON  "+version+" [COLOR red]        ····[COLOR yellowgreen]by Bad-Max[COLOR red]····[/B][/COLOR]"
	



# Punto de Entrada
def run():
	plugintools.log('[%s %s] Running %s... ' % (addonName, addonVersion, addonName))

	# Obteniendo parámetros...
	params = plugintools.get_params()
    
	
	if params.get("action") is None:
		main_list(params)
	else:
		action = params.get("action")
		exec(action+"(params)")
        

	plugintools.close_item_list()            



# Principal
def main_list(params):

    xbmcplugin.setContent( int(sys.argv[1]) ,"tvshows" )

    data = ""
    data = httptools.downloadpage(web).data
    
    #Saco las diferentes categorias
    acotacion = 'class="sub-menu'
    grupos1 = plugintools.find_single_match(data,acotacion+'(.*?)</ul')
    grupos = plugintools.find_multiple_matches(grupos1,'<li id(.*?)</li')
    #plugintools.log("*****************Grupos: "+str(len(grupos))+"********************")
    
    plugintools.add_item(action="",url="",title=cabecera,thumbnail=logo1,fanart=fondo,folder=False,isPlayable=False)
    plugintools.add_item(action="",url="",title="",thumbnail=logo_transparente, fanart=fondo, folder=False, isPlayable=False)

    for item in grupos:
        url = plugintools.find_single_match(item,'a href="(.*?)"').strip()
        titu = plugintools.find_single_match(item,'/">(.*?)<').strip()  ##.title()
        logo = logo1

        plugintools.add_item(action="abre_categoria",url=url,title='[COLOR white]' + titu + '[/COLOR]' ,thumbnail=logo, fanart=fondo, folder=True, isPlayable=False)
	
    datamovie = {}
    datamovie["Plot"]="Buscar Documentales por palabras clave."
    plugintools.add_item(action="abre_categoria",url="",title="[COLOR blue]Búsqueda[/COLOR]",extra="busca", thumbnail=logobusca, fanart=fondo, info_labels = datamovie, folder=True, isPlayable=False)
    datamovie = {}
    datamovie["Plot"]="Salir de DocumentalesON..."
    plugintools.add_item(action="salida",url="",title="[COLOR red]Salir[/COLOR]",thumbnail=logo_salida, extra="", fanart="https://i.imgur.com/Cp1t1lb.png", info_labels = datamovie, folder=False, isPlayable=False)





def abre_categoria(params):
    url = params.get("url")
    titu = params.get("title")
    logo1 = params.get("thumbnail")
    extra = params.get("extra")

    xbmcplugin.setContent( int(sys.argv[1]) ,"tvshows" )
        
    #Para comprobar los videos que ya estén vistos y así marcarlos como vistos.
    if marcar_visto:
        #v=open(vistos, "r")
        if sys.version_info[0] < 3:
            v = open( vistos, "r" )
        else:
            v = open( vistos, "r", encoding='utf-8' )

        docus_vistos = v.read()
        v.close()

    if extra == "busca":
        busqueda = plugintools.keyboard_input('', 'Introduzca [COLOR red]Texto[/COLOR] a Buscar.')
        if len(busqueda) == 0:
            xbmc.executebuiltin('ActivateWindow(10000,return)')  ##Vuelvo al menú ppal.
            
        titu = "          [B][COLOR blue]·····  BÚSQUEDA:[/COLOR]  " + busqueda + "  [COLOR blue]·····[/COLOR][/B]"
        url = web + "?s=" + busqueda.replace(" ", "+") ##https://www.documentaleson.com/?s=los+mayas
        
        extra = "TITU_ORIGEN:" + titu + "LOGO_ORIGEN:" + logo1 + "<Fin"
        
    elif len(extra) != 0: ## Si trae texto y no es "busca" es q viene de llamada recursiva por paginación
        #Entraigo Titulo y logo de 1ª página
        titu = plugintools.find_single_match(extra,'TITU_ORIGEN:(.*?)LOGO_')
        logo1 = plugintools.find_single_match(extra,'LOGO_ORIGEN:(.*?)<Fin')
        #plugintools.log("*****************Titu: "+titu+"********************")
        
    else:
        titu = "           [B]" + titu.upper().replace("[COLOR WHITE]" , "[COLOR darkorange]·····  ").replace("[/COLOR]" , "  ·····[/COLOR]") + "[/B]"
        #Meto en extra el titulo y el logo por si viene de vuelta en llamada de paginación
        extra = "TITU_ORIGEN:" + titu + "LOGO_ORIGEN:" + logo1 + "<Fin"
    
    if not "https://" in url: ##Viene de paginación de Búsqueda, que no incluye la ruta completa
        url = web + url
    
    data = ""
    data = httptools.downloadpage(url).data
    
    acotacion = 'class="entry-title'
    videos = plugintools.find_multiple_matches(data,acotacion+'(.*?)</article')

    plugintools.add_item(action="",url="",title=titu,thumbnail=logo1,fanart=fondo,folder=False,isPlayable=False)
    plugintools.add_item(action="",url="",title="",thumbnail=logo_transparente, fanart=fondo, folder=False, isPlayable=False)

    #Pongo todos los videos de la página
    for item in videos:
        #Para comprobar si existe video o está caido, abriré cada página y lo compruebo
        pag_docu = plugintools.find_single_match(item,'href="(.*?)"').strip()
        data_docu = httptools.downloadpage(pag_docu).data
        
        acotacion = 'title>'
        titulo = plugintools.find_single_match(data_docu,acotacion+'(.*?)<').replace("- Documentales Online","").strip()
        acotacion = 'class="entry-content clearfix'
        descrip0 = plugintools.find_single_match(data_docu,acotacion+'(.*?)</p') + "/fin>"
        descrip = plugintools.find_single_match(descrip0,'<p>(.*?)/fin>')
        
        if not 'embedURL" content=' in data_docu:  ##Es que no hay video
            accion = ""
            url = ""
            mivideo = ""
            titu = '[COLOR white]' + titulo + '     [COLOR red](Video Eliminado)[/COLOR]'
            logo = no_disponible
        else:
            accion = "lanza"
            titu = '[COLOR white]' + titulo + "[/COLOR]"
            acotacion = 'image" content="'
            logo = plugintools.find_single_match(data_docu,acotacion+'(.*?)"')
            id_vid = plugintools.find_single_match(data_docu,'youtube.com/embed/(.*?)"')
            #plugintools.log("*****************ID-Vid: "+id_vid+"********************")
            if usa_duffyou:  ##Usamos plugin Duff You
                reemplaza = base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-VIDEO" , id_vid)
                mivideo = "plugin://plugin.video.duffyou/?" + base64.b64encode(reemplaza.encode('utf-8')).decode('utf-8')
            else:  ##Usamos pluin YouTube
                mivideo = youtube.replace("MI-ID-VIDEO" , id_vid)  ##plugin://plugin.video.youtube/play/?video_id=16rE9HoGT7g
                
        #Comprobamos si alguno está en la BD de vistos, y si es así lo marco como visto.
        marcalo = ""
        if marcar_visto:
            if titulo in docus_vistos:
                marcalo = "[COLOR green][B]Visto [/B]"
        
        titu = marcalo + titu

        datamovie = {}
        datamovie["Plot"] = descrip
        plugintools.add_item(action=accion, url=mivideo, title=titu, extra=titulo, genre="NOGESTIONAR", thumbnail=logo, fanart=fondo, info_labels = datamovie, folder=False, isPlayable=False)
        
    #Busco la paginación
    acotacion = 'class="navigation pagination'
    bloque1 = plugintools.find_single_match(data,acotacion+'(.*?)</nav')

    if len(bloque1) != 0:  ##Si es diferente de 0, hay mas de 1 página... si no, no busco paginación pues no la hay
        #Acoto cada linea
        acotacion = 'page-numbers"'
        bloquepag = plugintools.find_multiple_matches(bloque1,acotacion+'(.*?)/a>')
        #La página actual está en la linea con la clase=active y la última página está en la penúltima línea siempre
        acota1 = 'numbers current">'
        pagactiva = plugintools.find_single_match(bloque1,acota1+'(.*?)<')
        
        #última página (penúltima línea = -2)
        pagfin = plugintools.find_single_match(bloquepag[-2],'">(.*?)<')
        
        #if pagactiva == pagfin: #Estoy en la última y no doy opción de avanzar página
        if not 'class="next page' in bloque1: #Estoy en la última y no doy opción de avanzar página
            texto = "[COLOR mediumaquamarine]Pág: " + pagactiva + " / " + pagactiva + "[/COLOR]"
            accion = ""
            url_siguiente = ""
            el_logo = logo_finpag
            plugintools.add_item(action=accion, url=url_siguiente, title=texto, extra=extra ,thumbnail=el_logo, fanart=fondo, folder=False, isPlayable=False)
        else:
            texto = "[COLOR mediumaquamarine]Pág: " + pagactiva + " / " + pagfin + "[COLOR lime]          Ir a Siguiente >>>[/COLOR]"
            accion = "abre_categoria" ##Recursividad
            #Como no es la última, busco la url de la siguiente página (que siempre está en la última línea, la -1 en la tabla)
            url_siguiente = plugintools.find_single_match(bloquepag[-1],'href="(.*?)"')
            el_logo = logo_siguiente
            plugintools.add_item(action=accion, url=url_siguiente, title=texto, extra=extra ,thumbnail=el_logo, fanart=fondo, folder=True, isPlayable=False)
            
        plugintools.add_item(action="main_list", url="", title="[COLOR orangered]···· Volver a Menú Principal ····[/COLOR]", extra=extra ,thumbnail=logo_volver, fanart=fondo, folder=True, isPlayable=False)
    
    
    
    


def lanza(params):
    mivideo = params.get("url")
    logo = params.get("thumbnail")
    titu = params.get("title")
    titulo = params.get("extra")
    
    xbmc.Player().play(mivideo)

    if marcar_visto:
        import time
        time.sleep(10)  # Para darle tiempo a q el .isPlaying pueda detectar que está reproduciendo
        while xbmc.Player().isPlaying():
            time.sleep(1)

        if  not "[COLOR green][B]" in titu:  # El video NO está marcado aún como "Visto", así q lo marco
            marcar = True
            if pregunta_marcar:
                marcar  = xbmcgui.Dialog().yesno("¡¡Atención!!", "¿Desea Marcar como 'VISTO' este Video?:"+"\n\n"+titulo )
            if marcar:
                if sys.version_info[0] < 3:
                    fichero = open( vistos, "a" )
                else:
                    fichero = open( vistos, "a", encoding='utf-8' )

                fichero.write(titulo+"\n")  # Añado todo el Titulo completo del video al final del fichero de control
                fichero.close()




def salida(params):

	xbmc.executebuiltin('ActivateWindow(10000,return)')
	



	


	


		
run()

		




	

